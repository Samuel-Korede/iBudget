<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ibudget";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Ended");
}

if (isset($_POST['login'])) {


   

 if (isset($_POST['email-username']) && isset($_POST['password']) ){
   $email_username = $_POST['email-username'];
   $loginpassword = $_POST['password'];

   if($email_username == "admin" && $loginpassword == "admin"){
    header("location:admin.php");
}else{
    $login_query = "SELECT * FROM users WHERE (email = '$email_username' OR username = '$email_username') AND password = '$loginpassword'";
    $login_result = $conn->query($login_query);
    if ($login_result->num_rows > 0) {
        $rw = mysqli_fetch_array($login_result);
        session_start();
        $_SESSION['id'] = $rw['id'];
     header("location:dashboard.php");
    } else {
        header("location:login.php");
        session_start();
        $_SESSION['err_message'] = "Incorrect username or password";
     
    };
}
    

 }
    
}
elseif (isset($_POST['register'])) {
  

    $username = $_POST['username'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $password = $_POST['password'];
        $confirmpassword = $_POST['confirm-password'];
     if(($username != "") and ($email != "") and ($phone != "") and ($password != "") and ($confirmpassword != "")){ 
        if ($password === $confirmpassword) {
            $users_query = "INSERT INTO users(username , email , phoneno , password) VALUES ('$username','$email','$phone','$password')";
            if (mysqli_query($conn, $users_query)) {
                header("location:login.php");

            }
            else {
                header("location:register.php");
                session_start();
                $_SESSION['err_message'] = "You entered those details incorrectly";

            }
        }
        else {
            header("location:register.php");
            session_start();
            $_SESSION['err_message'] = "Password and confirm password not same";
        }

     }else{
        header("location:register.php");
        session_start();
        $_SESSION['err_message'] = "You Cannot Submit an Empty form";
     }
       
    
 
}elseif (isset($_POST['add_budget'])) {
 
    if (isset($_POST['budget_name']) || isset($_POST['start_date']) || isset($_POST['end_date']) || isset($_POST['salary']) || isset($_POST['income']) || isset($_POST['daily_living']) || isset($_POST['rent']) || isset($_POST['transport']) || isset($_POST['entertainment']) || isset($_POST['dues']) || isset($_POST['health']) || isset($_POST['misc'])) {
        $budget_name = $_POST['budget_name'];
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        $salary = $_POST['salary'];
        $income = $_POST['income']; 
        $daily_living = $_POST['daily_living'];
        $rent = $_POST['rent'];
        $transport = $_POST['transport']; 
        $entertainment = $_POST['entertainment'];
        $dues = $_POST['dues'];
        $health = $_POST['health']; 
        $misc = $_POST['misc'];

        session_start();
        $user = $_SESSION['id'];
        
        $budget_query = "INSERT INTO budget(user_id, salary, income, daily_living, rent, transport, entertainment, dues, health, misc, name, start_date, end_date) VALUES ('$user','$salary','$income','$daily_living','$rent','$transport','$entertainment','$dues','$health','$misc','$budget_name','$start_date','$end_date')";
        if (mysqli_query($conn, $budget_query)) {
            header("location:dashboard.php");
        }
        else {
            header("location:add-budget.php");
        }
    }else{
        header("location:dashboard.php");
    }

}elseif (isset($_POST['edit_budget'])) {
 
    if ( isset($_POST['daily_living']) || isset($_POST['rent']) || isset($_POST['transport']) || isset($_POST['entertainment']) || isset($_POST['dues']) || isset($_POST['health']) || isset($_POST['misc'])) {
       
        $daily_living = $_POST['daily_living'];
        $rent = $_POST['rent'];
        $transport = $_POST['transport']; 
        $entertainment = $_POST['entertainment'];
        $dues = $_POST['dues'];
        $health = $_POST['health']; 
        $misc = $_POST['misc'];

        session_start();
        $user = $_SESSION['id'];
        $edit_id = $_SESSION['edit_id'];
        $budgetedit_query = "UPDATE budget SET user_id='".$user."',daily_living='".$daily_living."',rent='".$rent."',transport='".$transport."',entertainment='".$entertainment."',dues='".$dues."',health='".$health."',misc = '".$misc."' WHERE id=".$edit_id;

       // $budget_query = "INSERT INTO budget(user_id, daily_living, rent, transport, entertainment, dues, health, misc) VALUES ('$user','$daily_living','$rent','$transport','$entertainment','$dues','$health','$misc')";
        if (mysqli_query($conn, $budgetedit_query)) {
            header("location:dashboard.php");
        }
        else {
            header("location:view.php?id="+$edit_id);
            
        }
    }else{
        header("location:dashboard.php");
    }

}
else {
    header("location:index.php");
}
?>