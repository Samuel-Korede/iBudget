<?php
//paste this in dashboard.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ibudget";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Ended");
}

session_start();
$user_id = $_SESSION['id'];
if(isset($_SESSION['id'])){
}else{
    header("location:login.php");
}
$budgetArray = array();
$budget_query = "SELECT name,(salary+income) AS income, (daily_living+rent+transport+entertainment+dues+health+misc) AS expense FROM budget WHERE user_id = '$user_id' ";
$budget_result = $conn->query($budget_query);

if ($budget_result->num_rows > 0) {
    // output data of each row
    while ($row = $budget_result->fetch_assoc()) {

      $budgetArray[] = $row;
     
    }
} else {
  
}


?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />
    <script src="../assets/js/jquery.js"></script>
    <title>View Budget </title>
    <meta name="description" content="" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />
    <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/apex-charts/apex-charts.css" />
    <script src="../assets/vendor/js/helpers.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <script src="../assets/js/config.js"></script>
    <script src="../assets/js/chart.js"></script>
  </head>
<body>
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
        <div> 
          <h2>iBudget</h2>
        </div>
        <div class="menu-inner-shadow"></div>
        <ul class="menu-inner py-1">
          <li class="menu-item">
            <a href="dashboard.php" class="menu-link">
              <div data-i18n="Analytics">Back</div>
            </a>
          </li>
        </ul>
      </aside>
      <div class="layout-page">
        <div class="content-wrapper">
          <div class="container-xxl flex-grow-1 container-p-y">
            <div class="card">
              <canvas id="myChart" style="width:50%;height:100px"></canvas>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<script>
var xValues = [];
var yValues = []
var barColors = [];
    var budgetArr = <?php echo json_encode($budgetArray)?>;
    for(var i = 0; i<budgetArr.length;i++){
       xValues.push(budgetArr[i].name);
       var income = budgetArr[i].income;
       var expenses = budgetArr[i].expense;
       var savings = income - expenses;
       yValues.push(savings);
       barColors.push("red");
    }




new Chart("myChart", {
  type: "bar",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "Expenses Chart"
    }
  }
});
</script>

</body>
</html>