<?php
session_start();
if(isset($_SESSION['id'])){
}else{
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />
    <script src="../assets/js/jquery.js"></script>
    <title>Add Budget </title>
    <meta name="description" content="" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />
    <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/apex-charts/apex-charts.css" />
    <script src="../assets/vendor/js/helpers.js"></script>
    <script src="../assets/js/config.js"></script>
  </head>
  <body>
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <div> 
                    <h2>iBudget</h2>
                </div>
                <div class="menu-inner-shadow"></div>   
                <ul class="menu-inner py-1">
                  <li class="menu-item">
                    <a href="dashboard.php" class="menu-link">
                      <i class="menu-icon tf-icons bx bx-home-circle"></i>
                      <div data-i18n="Analytics">Dashboard</div>
                    </a>
                  </li>
                  <li class="menu-item active">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                      <i class="menu-icon tf-icons bx bx-box"></i>
                      <div data-i18n="Misc">Budget</div>
                    </a>
                    <ul class="menu-sub">
                      <li class="menu-item">
                        <a href="#" class="menu-link">
                          <div data-i18n="User interface">Create New Budget</div>
                        </a>
                      </li>
                      <li class="menu-item">
                        <a href="view.php" class="menu-link">
                          <div data-i18n="Under Maintenance">View Budget</div>
                        </a>
                      </li>
                    </ul>
                  </li>
                  <li class="menu-item">
                    <a href="" class="menu-link">
                      <i class="bx bx-power-off me-2"></i>
                      <div data-i18n="Boxicons">Logout</div>
                    </a>
                  </li>
                </ul>
            </aside>
            <div class="layout-page">
                <nav
                  class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
                  id="layout-navbar"
                >
                  <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                    <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                      <i class="bx bx-menu bx-sm"></i>
                    </a>
                  </div>
                  <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                    <ul class="navbar-nav flex-row align-items-center ms-auto">
                      <li class="nav-item navbar-dropdown dropdown-user dropdown">
                        <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                          <div class="avatar avatar-online">
                            <img src="../assets/img/avatars/noUser.png" alt class="w-px-40 h-auto rounded-circle" />
                          </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                          <li>
                            <a class="dropdown-item" href="#">
                              <div class="d-flex">
                                <div class="flex-shrink-0 me-3">
                                  <div class="avatar avatar-online">
                                    <img src="../assets/img/avatars/noUser.png" alt class="w-px-40 h-auto rounded-circle" />
                                  </div>
                                </div>
                                <div class="flex-grow-1">
                                  <span class="fw-semibold d-block"></span>
                                  <small class="text-muted">Admin</small>
                                </div>
                              </div>
                            </a>
                          </li>
                          <li>
                            <div class="dropdown-divider"></div>
                          </li>
                          <li>
                            <a class="dropdown-item" href="settings.php">
                              <i class="bx bx-cog me-2"></i>
                              <span class="align-middle">My Profile Settings</span>
                            </a>
                          </li>
                          <li>
                            <div class="dropdown-divider"></div>
                          </li>
                          <li>
                            <a class="dropdown-item" href="logout.php">
                              <i class="bx bx-power-off me-2"></i>
                              <span class="align-middle">Log Out</span>
                            </a>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                </nav>
                <div class="content-wrapper">
                    <form action="requests.php" onsubmit="return validateForm()" method="post">
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <div class="card">
                            <h5 class="card-header">Disposable Income</h5>
                            <div class="card-body demo-vertical-spacing demo-only-element">
                              <div class="input-group input-group-merge">
                                <span class="input-group-text">Budget Name</span>
                                <input
                                  type="text"
                                  class="form-control"
                                  placeholder="Give Your Budget a Name"
                                  id="budget_name"
                                  name="budget_name"
                                />
                              </div>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Start Date</span>
                                    <input type="date" id="start_date" name="start_date"  class="form-control" />
                                    <span class="input-group-text">End Date</span>
                                    <input type="date" id="end_date"  name="end_date"  class="form-control" />
                                </div>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Salary/Wages</span>
                                    <span class="input-group-text">₦</span>
                                    <input
                                      type="number"
                                      class="form-control"
                                      id="salary"
                                         name="salary" 
                                    />
                                    <span class="input-group-text">.00</span>
                                               </div>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Other Income</span>
                                    <span class="input-group-text">₦</span>
                                    <input
                                      type="number"
                                      class="form-control"
                                      id="income"
                                         name="income" 
                                    />
                                    <span class="input-group-text">.00</span>
                                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <div class="card"> 
                            <h5 class="card-header">Budgeted Expenses</h5>
                            <div class="card-body demo-vertical-spacing demo-only-element">
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Daily Living</span>
                                    <span class="input-group-text">₦</span>
                                    <input
                                      type="number"
                                      class="form-control"
                                      id="daily_living" 
                                       name="daily_living" 
                                    />
                                    <span class="input-group-text">.00</span>
                                                    </div>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Home/Rent</span>
                                    <span class="input-group-text">₦</span>
                                    <input
                                      type="number"
                                      class="form-control"
                                      id="rent"
                                             name="rent" 
                                    />
                                    <span class="input-group-text">.00</span>
                                                  </div>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Transportation</span>
                                    <span class="input-group-text">₦</span>
                                    <input
                                      type="number"
                                      class="form-control"
                                      id="transport" 
                                      name="transport" 
                                    />
                                    <span class="input-group-text">.00</span>
                                          </div>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Entertainment</span>
                                    <span class="input-group-text">₦</span>
                                    <input
                                      type="number"
                                      class="form-control"
                                      id="entertainment"
                                      name="entertainment"
                                    />
                                    <span class="input-group-text">.00</span>
                                       </div>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Dues/Subcriptions</span>
                                    <span class="input-group-text">₦</span>
                                    <input
                                      type="number"
                                      class="form-control"
                                      id="dues"
                                      name="dues" 
                                    />
                                    <span class="input-group-text">.00</span>
                                      </div>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Health/Wellness</span>
                                    <span class="input-group-text">₦</span>
                                    <input
                                      type="number"
                                      class="form-control"
                                      id="health" 
                                      name="health" 
                                    />
                                    <span class="input-group-text">.00</span>
                                        </div>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">Miscellaneous Payments</span>
                                    <span class="input-group-text">₦</span>
                                    <input
                                      type="number"
                                      class="form-control"
                                      id="misc" 
                                      name="misc" 
                                    />
                                    <span class="input-group-text">.00</span>
                                      </div>
                                <button name="add_budget" class="btn btn-outline-primary" type="submit">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

     <!-- jquery -->
    

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  <script type="text/javascript">


function isset (ref) {
   return typeof ref !== 'undefined' 
  }
  
function validateForm(){

  var salary_name = $("#salary_name").val();
   var salary = Number($("#salary").val());
   var startdate = $("#start_date").val();
   var enddate = $("#end_date").val();
   var income = Number($("#income").val());
   var daily_living = Number($("#daily_living").val());
   var rent = Number($("#rent").val());
   var transport = Number($("#transport").val());
   var entertainment = Number($("#entertainment").val());
   var dues = Number($("#dues").val());
   var health = Number($("#health").val());
   var misc = Number($("#misc").val());
   
   var startdate = $("#start_date").val();
   var enddate = $("#end_date").val();
   var date1 = new Date(startdate);
var date2 = new Date(enddate);
var Difference_In_Time = date2.getTime() - date1.getTime();
var diff = Difference_In_Time / (1000 * 3600 * 24);

if(!(isset(salary))){
salary = 0;
$("#salary").val(0);
}
if(!(isset(income))){
income = 0;
$("#income").val(0);
}
if(!(isset(daily_living))){
daily_living = 0;
$("#daily_living").val(0);
}else{

}
if(!(isset(rent))){
rent = 0;
$("#rent").val(0);
}
if(!(isset(transport))){
transport = 0;
$("# transport").val(0);
}
if(!(isset(entertainment))){
entertainment = 0;
$("#entertainment").val(0);
}
if(!(isset(dues))){
dues = 0;
$("#dues").val(0);
}
if(!(isset(health))){
health = 0;
$("#health").val(0);
}
if(!(isset(misc))){
misc = 0;
$("#misc").val(0);
}
console.log(diff);
var totalliving = daily_living * diff;
var totalspending =  totalliving + rent + entertainment + dues + misc + health + transport;
var totalincome = salary + income;
console.log(totalliving)
console.log(totalincome+"<"+totalspending)
$("#daily_living").val(totalliving);
if(totalincome < totalspending){   

  console.log(totalincome+"<"+totalspending)
alert("Your yourn expenses cannot be more than your your income. Please change your budget.");

return false;
}

}


   
  
   
  </script>
  </body>
</html>