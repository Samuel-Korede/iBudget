<?php
//paste this in view.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ibudget";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Ended");
}

session_start();
$user_id = $_SESSION['id'];
if(isset($_SESSION['id'])){
}else{
    header("location:login.php");
}
$budgetArray = array();
$budget_query = "SELECT * FROM budget WHERE id ='$id' AND user_id = '$user_id' ";
$budget_result = $conn->query($budget_query);

if ($budget_result ->num_rows > 0) {
    // output data of each row
    while ($row = $budget_result->fetch_assoc()) {

      $budgetArray[] = $row['daily_living'];
      $budgetArray[]  =  $row['rent'];
      $budgetArray[]  = $row['transport'];
      $budgetArray[]  =  $row['entertainment'];
      $budgetArray[]  = $row['dues'];
      $budgetArray[]  =  $row['health'];
      $budgetArray[]  = $row['misc'];
    }
} else {
  
}

?>

<!DOCTYPE html>
<html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<body>

<canvas id="myChart" style="width:100%;max-width:600px"></canvas>

<script>
  var yValues = []
   var one = <?php echo json_encode($budgetArray[0])?>;
   var daily_living = parseInt(one);
   yValues.push(daily_living)
   var second = <?php echo json_encode($budgetArray[1])?>;
   var rent = parseInt(second);
   yValues.push(rent)
   var third = <?php echo json_encode($budgetArray[2])?>;
   var transport = parseInt(third);
   yValues.push(transport)
   var fourth = <?php echo json_encode($budgetArray[3])?>;
   var entertainment = parseInt(fourth);
   yValues.push(entertainment)
   var fifth = <?php echo json_encode($budgetArray[4])?>;
   var dues = parseInt(fifth);
   yValues.push(dues)
   var sixth = <?php echo json_encode($budgetArray[5])?>;
   var health = parseInt(sixth);
   yValues.push(health)
   var seventh = <?php echo json_encode($budgetArray[6])?>;
   var misc = parseInt(seventh);
   yValues.push(misc)

var xValues = ["Daily Living", "Home/Rent","Transportation", "Entertainment","Dues/Subscriptions", "Health/Wellness","Miscellaneous Payments"];

var barColors = [
  "#b91d47",
  "#00aba9",
  "#2b5797",
  "#e8c3b9",
  "#1e7145"
];

new Chart("myChart", {
  type: "pie",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "Expenses Chart"
    }
  }
});
</script>

</body>
</html>