<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ibudget";
$id = 0 ;
$totalincome = 0 ;
$totalspending = 0 ;
$daily_spending = 0;
$salary = 0;
$income = 0;
$rent = 0; 
$transport = 0 ;
$entertainment = 0;
$dues = 0;
$health = 0;
$misc = 0;
$name = "";
$startdate ="";
$enddate = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Ended");
}

session_start();

$user_id = $_SESSION['id'];
if(isset($_SESSION['id'])){
}else{
    header("location:login.php");
}

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $_SESSION['edit_id'] = $id;
}
$user_id = $_SESSION['id'];
if(isset($_SESSION['id'])){
}else{
    header("location:login.php");
}

     $user_query = "SELECT * FROM users WHERE id ='$user_id'  ";
$user_result = $conn->query($user_query);

if ($user_result ->num_rows > 0) {
    // output data of each row
    while ($row = $user_result->fetch_assoc()) {

      $ownerName = $row['username'];
     
      
    }
} else {
  
}

$budget_query = "SELECT * FROM budget WHERE id ='$id' AND user_id = '$user_id' ";
$budget_result = $conn->query($budget_query);

if ($budget_result ->num_rows > 0) {
    // output data of each row
    while ($row = $budget_result->fetch_assoc()) {

      $daily_spending = $row['daily_living'];
      $rent =  $row['rent'];
      $transport = $row['transport'];
      $entertainment =  $row['entertainment'];
      $dues = $row['dues'];
      $health =  $row['health'];
      $misc = $row['misc'];
    }
} else {
  
}
$totalspending_query = "SELECT sum(daily_living + rent + transport + entertainment + dues + health + misc ) as spending from budget WHERE id ='$id' AND user_id = '$user_id' ";
$totalspending_result = $conn->query($totalspending_query);


if ($totalspending_result ->num_rows > 0) {
    // output data of each row
    while ($row = $totalspending_result->fetch_assoc()) {

      $totalspending= $row['spending'];
    
    }
} else {
}

$totalincome_query = "SELECT sum(salary + income ) as total from budget WHERE id ='$id' AND user_id = '$user_id' ";
$totalincome_result = $conn->query($totalincome_query);


if ($totalincome_result ->num_rows > 0) {
    // output data of each row
    while ($row = $totalincome_result->fetch_assoc()) {

      $totalincome= $row['total'];
    
    }
} else {
}
$budgetArrayjs = array();
$budget_queryjs = "SELECT * FROM budget WHERE id ='$id' AND user_id = '$user_id' ";
$budget_resultjs = $conn->query($budget_queryjs);

if ($budget_resultjs ->num_rows > 0) {
    // output data of each row
    while ($row = $budget_resultjs->fetch_assoc()) {

      $budgetArrayjs[] = $row['daily_living'];
      $budgetArrayjs[]  =  $row['rent'];
      $budgetArrayjs[]  = $row['transport'];
      $budgetArrayjs[]  =  $row['entertainment'];
      $budgetArrayjs[]  = $row['dues'];
      $budgetArrayjs[]  =  $row['health'];
      $budgetArrayjs[]  = $row['misc'];
    }
} else {
  
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />
    <script src="../assets/js/jquery.js"></script>
    <title>View Budget </title>
    <meta name="description" content="" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />
    <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/apex-charts/apex-charts.css" />
    <script src="../assets/vendor/js/helpers.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.8.0/chart.min.js" 
    integrity="sha512-sW/w8s4RWTdFFSduOTGtk4isV1+190E/GghVffMA9XczdJ2MDzSzLEubKAs5h0wzgSJOQTRYyaz73L3d6RtJSg==" 
    crossorigin="anonymous"
     referrerpolicy="no-referrer"></script>
    <script src="../assets/js/config.js"></script>
    <script src="../assets/js/chart.js"></script>
  </head>
  <body>
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <div> 
                    <h2>iBudget</h2>
                </div>
                <div class="menu-inner-shadow"></div>
      
                <ul class="menu-inner py-1">
                  <!-- Dashboard -->
                  <li class="menu-item">
                    <a href="dashboard.php" class="menu-link">
           
                      <div data-i18n="Analytics">Back</div>
                    </a>
                  </li>
                </ul>
            </aside>
            <div class="layout-page">
                <!-- Navbar -->
                <nav
                  class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
                  id="layout-navbar"
                >
                  <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                    <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                      <i class="bx bx-menu bx-sm"></i>
                    </a>
                  </div>
      
                  <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                    <ul class="navbar-nav flex-row align-items-center ms-auto">
                      <!-- User -->
                      <li class="nav-item navbar-dropdown dropdown-user dropdown">
                        <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                          <div class="avatar avatar-online">
                            <img src="../assets/img/avatars/noUser.png" alt class="w-px-40 h-auto rounded-circle" />
                          </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                          <li>
                            <a class="dropdown-item" href="#">
                              <div class="d-flex">
                                <div class="flex-shrink-0 me-3">
                                  <div class="avatar avatar-online">
                                    <img src="../assets/img/avatars/noUser.png" alt class="w-px-40 h-auto rounded-circle" />
                                  </div>
                                </div>
                                <div class="flex-grow-1">
                                  <span class="fw-semibold d-block"></span>
                                  <small class="text-muted"><?php echo $ownerName?></small>
                                </div>
                              </div>
                            </a>
                          </li>
                          <li>
                            <div class="dropdown-divider"></div>
                          </li>
                          <li>
                            <a class="dropdown-item" href="settings.php">
                              <i class="bx bx-cog me-2"></i>
                              <span class="align-middle">My Profile Settings</span>
                            </a>
                          </li>
                          <li>
                            <div class="dropdown-divider"></div>
                          </li>
                          <li>
                            <a class="dropdown-item" href="logout.php">
                              <i class="bx bx-power-off me-2"></i>
                              <span class="align-middle">Log Out</span>
                            </a>
                          </li>
                        </ul>
                      </li>
                      <!--/ User -->
                    </ul>
                  </div>
                </nav>
                <div class="content-wrapper">
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <div class="card">
                            <div class="card-header d-flex align-items-center justify-content-between pb-0">
                                <div class="card-title mb-0">
                                  <h5 class="m-0 me-2">Statistics</h5>
                                  <small class="text-muted"></small>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                  <div class="d-flex flex-column align-items-center gap-1">
                                    <h2 class="mb-2">₦<?php echo $totalincome;?></h2>
                                    <span>Total Income for The selected days</span>
                                  </div>
                                  <div class="d-flex flex-column align-items-center gap-1">
                                    <h2 class="mb-2">₦<?php echo $totalincome - $totalspending;?></h2>
                                    <span>Total Savings for The selected days</span>
                                  </div>
                                  <div class="user-progress">
                                  <canvas id="myChart" style="width:100%;max-width:600px"></canvas>
                                  </div>
                                  
                                </div>
                                <ul class="p-0 m-0">
                                  <li class="d-flex mb-4 pb-1">
                                  
                                    <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                      <div class="me-2">
                                        <h6 class="mb-0">Daily Living</h6>
                                        <small class="text-muted"></small>
                                      </div>
                                      <div class="user-progress">
                                        <small class="fw-semibold">₦<?php echo $daily_spending?></small>
                                      </div>
                                    </div>
                                  </li>
                                  <li class="d-flex mb-4 pb-1">
                                    <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                      <div class="me-2">
                                        <h6 class="mb-0">Home/Rent</h6>
                                        <small class="text-muted"></small>
                                      </div>
                                      <div class="user-progress">
                                        <small class="fw-semibold">₦<?php echo $rent?></small>
                                      </div>
                                    </div>
                                  </li>
                                  <li class="d-flex mb-4 pb-1">

                                    <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                      <div class="me-2">
                                        <h6 class="mb-0">Transportation</h6>
                                        <small class="text-muted"></small>
                                      </div>
                                      <div class="user-progress">
                                        <small class="fw-semibold">₦<?php echo $transport?></small>
                                      </div>
                                    </div>
                                  </li>
                                  <li class="d-flex mb-4 pb-1">
                                
                                    <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                      <div class="me-2">
                                        <h6 class="mb-0">Entertainment</h6>
                                        <small class="text-muted"></small>
                                      </div>
                                      <div class="user-progress">
                                        <small class="fw-semibold">₦<?php echo $entertainment?></small>
                                      </div>
                                    </div>
                                  </li>
                                  <li class="d-flex mb-4 pb-1">
                              
                                    <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                      <div class="me-2">
                                        <h6 class="mb-0">Dues/Subcriptions</h6>
                                        <small class="text-muted"></small>
                                      </div>
                                      <div class="user-progress">
                                        <small class="fw-semibold">₦<?php echo $dues ?></small>
                                      </div>
                                    </div>
                                  </li>
                                  <li class="d-flex mb-4 pb-1">
                               
                                    <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                      <div class="me-2">
                                        <h6 class="mb-0">Health/Wellness</h6>
                                        <small class="text-muted"></small>
                                      </div>
                                      <div class="user-progress">
                                        <small class="fw-semibold">₦<?php echo $health?></small>
                                      </div>
                                    </div>
                                  </li>
                                  <li class="d-flex">
                               
                                    <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                      <div class="me-2">
                                        <h6 class="mb-0">Miscellaneous</h6>
                                        <small class="text-muted"></small>
                                      </div>
                                      <div class="user-progress">
                                        <small class="fw-semibold">₦<?php echo $misc ?></small>
                                      </div>
                                    </div>
                                  </li>
                                </ul>
                            </div>
                            <div class="card-header d-flex align-items-center justify-content-between pb-0">
                                <div class="card-title mb-0">
                                    <h5 class="m-0 me-2">Edit Budget</h5>
                                </div>
                            </div>
                            <div class="container-xxl flex-grow-1 container-p-y">
                            <form action="requests.php" onsubmit="return validateForm()" method="post">
                      
                            <div class="card"> 
                                    <h5 class="card-header">Budgeted Expenses</h5>
                                    <div class="card-body demo-vertical-spacing demo-only-element">
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text">Daily Living</span>
                                            <span class="input-group-text">₦</span>
                                            <input
                                              type="number"
                                              class="form-control"
                                              id="daily_living" 
                                       name="daily_living" 
                                       value="<?php echo $daily_spending?>"
                                              aria-label="Amount (to the nearest Naira)"
                                            />
                                            <span class="input-group-text">.00</span>
                                              </div>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text">Home/Rent</span>
                                            <span class="input-group-text">₦</span>
                                            <input
                                              type="number"
                                              class="form-control"
                                              id="rent"
                                             name="rent" 
                                             value="<?php echo $rent?>"
                                              aria-label="Amount (to the nearest Naira)"
                                            />
                                            <span class="input-group-text">.00</span>
                                             </div>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text">Transportation</span>
                                            <span class="input-group-text">₦</span>
                                            <input
                                              type="number"
                                              class="form-control"
                                              id="transport" 
                                      name="transport" 
                                      value="<?php echo $transport?>"
                                              aria-label="Amount (to the nearest Naira)"
                                            />
                                            <span class="input-group-text">.00</span>
                                            </div>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text">Entertainment</span>
                                            <span class="input-group-text">₦</span>
                                            <input
                                              type="number"
                                              class="form-control"
                                              id="entertainment"
                                              name="entertainment"
                                              value="<?php echo $entertainment?>"
                                              aria-label="Amount (to the nearest Naira)"
                                            />
                                            <span class="input-group-text">.00</span>
                                               </div>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text">Dues/Subcriptions</span>
                                            <span class="input-group-text">₦</span>
                                            <input
                                              type="number"
                                              class="form-control"
                                              id="dues"
                                             name="dues" 
                                             value="<?php echo $dues?>"
                                              aria-label="Amount (to the nearest Naira)"
                                            />
                                            <span class="input-group-text">.00</span>
                                          </div>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text">Health/Wellness</span>
                                            <span class="input-group-text">₦</span>
                                            <input
                                              type="number"
                                              id="health" 
                                              name="health" 
                                              value="<?php echo $health?>"
                                              class="form-control"
                                                 />
                                            <span class="input-group-text">.00</span>
                                             </div>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text">Miscellaneous Payments</span>
                                            <span class="input-group-text">₦</span>
                                            <input
                                              type="number"
                                              class="form-control"
                                              id="misc" 
                                             name="misc" 
                                             value="<?php echo $misc?>"
                                              aria-label="Amount (to the nearest Naira)"
                                            />
                                            <span class="input-group-text">.00</span>
                                           </div>
                                        <button class="btn btn-outline-primary" name="edit_budget" type="submit">Submit</button>
                                       </form>       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>
    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  <script>
    var yValues = []
   var one = <?php echo json_encode($budgetArrayjs[0])?>;
   var daily_living = parseInt(one);
   yValues.push(daily_living)
   var second = <?php echo json_encode($budgetArrayjs[1])?>;
   var rent = parseInt(second);
   yValues.push(rent)
   var third = <?php echo json_encode($budgetArrayjs[2])?>;
   var transport = parseInt(third);
   yValues.push(transport)
   var fourth = <?php echo json_encode($budgetArrayjs[3])?>;
   var entertainment = parseInt(fourth);
   yValues.push(entertainment)
   var fifth = <?php echo json_encode($budgetArrayjs[4])?>;
   var dues = parseInt(fifth);
   yValues.push(dues)
   var sixth = <?php echo json_encode($budgetArrayjs[5])?>;
   var health = parseInt(sixth);
   yValues.push(health)
   var seventh = <?php echo json_encode($budgetArrayjs[6])?>;
   var misc = parseInt(seventh);
   yValues.push(misc)

var xValues = ["Daily Living", "Home/Rent","Transportation", "Entertainment","Dues/Subscriptions", "Health/Wellness","Miscellaneous Payments"];

var barColors = [
  "#b91d47",
  "#00aba9",
  "#2b5797",
  "#e8c3b9",
  "#1e7145"
];

new Chart("myChart", {
  type: "pie",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "Expenses Chart"
    }
  }
});
  </script>
    <script type="text/javascript">


function isset (ref) {
   return typeof ref !== 'undefined' 
  }
  
function validateForm(){


  
   var daily_living = Number($("#daily_living").val());
   var rent = Number($("#rent").val());
   var transport = Number($("#transport").val());
   var entertainment = Number($("#entertainment").val());
   var dues = Number($("#dues").val());
   var health = Number($("#health").val());
   var misc = Number($("#misc").val());
   
  





if(!(isset(daily_living))){
daily_living = 0;
$("#daily_living").val(0);
}else{

}
if(!(isset(rent))){
rent = 0;
$("#rent").val(0);
}
if(!(isset(transport))){
transport = 0;
$("# transport").val(0);
}
if(!(isset(entertainment))){
entertainment = 0;
$("#entertainment").val(0);
}
if(!(isset(dues))){
dues = 0;
$("#dues").val(0);
}
if(!(isset(health))){
health = 0;
$("#health").val(0);
}
if(!(isset(misc))){
misc = 0;
$("#misc").val(0);
}


}


   
  
   
  </script>
  <script type = "text/javascript" src></script>

</body>

</html>