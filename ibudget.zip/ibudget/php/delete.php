<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ibudget";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Ended");
}

session_start();
$user_id = $_SESSION['id'];
if(isset($_SESSION['id'])){
}else{
    header("location:login.php");
}

if(isset($_GET['id'])){
    $id = $_GET['id'];
}
$delete_query = "DELETE FROM budget WHERE id='$id' AND user_id = '$user_id'";

if (mysqli_query($conn, $delete_query)) {
  header("location:dashboard.php");
} else {
    header("location:dashboard.php");
}



?>